from lib.bot import bot

bot.run()

